console.log("Hola mundo...");

function nuevoCoche() {
    document.getElementById('nuevoCoche').style.display = 'flex';
}

function cerrarCoche() {
    document.getElementById('nuevoCoche').style.display = 'none';
}